from Graph import Graph


    g = Graph(nodes=[1], edges=None, children=None, parentss=None)
    print(g)
    print(g.threshold)