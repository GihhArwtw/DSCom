EPSILON = 0.5
l = 3
k = 10
GRAPH_PATH = "ER_graph.txt"